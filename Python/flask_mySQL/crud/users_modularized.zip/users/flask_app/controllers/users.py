from flask import render_template, redirect, request, session
from flask_app import app
from flask_app.models.user import User

@app.route('/')
def index():
    users = User.get_all()
    return render_template('index.html', all_users = users)

@app.route('/create_user', methods = ['POST'])
def create_user():
    data = {
        "first_name": request.form['first_name'],
        "last_name": request.form['last_name'],
        "email": request.form['email']
    }
    User.save(data)

    return redirect('/')

@app.route('/new_user')
def new_user():
    return render_template('new_user.html')

@app.route('/user/<int:user_id>')
def show_user(user_id):
    this_user = User.get_one_user({'id': user_id })

    return render_template('user.html', user = this_user)


@app.route('/user/<int:user_id>/edit_user')
def edit_user(user_id):
    this_user = User.get_one_user({'id': user_id })
    return render_template('edit_user.html', user = this_user)

@app.route('/update/<int:user_id>', methods = ['POST'])
def update(user_id):
    data  = {
        "first_name": request.form['first_name'],
        "last_name": request.form['last_name'],
        "email": request.form['email'],
        "id": user_id
    }

    print(data)
    User.update(data)

    return redirect(f'/user/{user_id}')

@app.route('/delete/<int:user_id>')
def delete(user_id):
    User.delete({'id': user_id})

    return redirect('/')