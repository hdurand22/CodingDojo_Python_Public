from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import language, dojo
from flask import flash

class User:
    def __init__(self, data):
        self.id = data['id']
        self.dojo_id = data['dojo_id']
        self.language_id = data['language_id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.comment = data['comment']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    # @classmethod
    # def get_all(cls):
    #     query = "SELECT * FROM users;"
    #     results = connectToMySQL('dojo_survey_schema').query_db(query)
    #     users = []
    #     for user in results:
    #         # print(user)
    #         users.append(cls(user))
        
    #     return users
    
    @classmethod
    def get_survey(cls, data):
        query = "SELECT * FROM users WHERE users.id = %(id)s;"
        results = connectToMySQL('dojo_survey_schema').query_db(query, data)

        return results
    
    @classmethod
    def save(cls, data):
        query = "INSERT INTO users (dojo_id, language_id, first_name, last_name, comment, created_at, updated_at) VALUES (%(dojo_id)s, %(language_id)s, %(first_name)s , %(last_name)s , %(comment)s , NOW() , NOW());"

        return connectToMySQL('dojo_survey_schema').query_db(query, data)

    @staticmethod
    def validate_survey(user):
        is_valid = True # we assume this is true
        if len(user['first_name']) < 2:
            flash("First name must be at least 2 characters.")
            is_valid = False
        if len(user['last_name']) < 2:
            flash("Last name must be at least 2 characters.")
            is_valid = False
        if user['dojo_id'] == "":
            flash("Please select a dojo.")
            is_valid = False
        if user['language_id'] == "":
            flash("Please select your favorite language.")
            is_valid = False
        return is_valid

