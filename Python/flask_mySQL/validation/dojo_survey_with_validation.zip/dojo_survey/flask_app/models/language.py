from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import user, dojo

class Language:
    def __init__(self, data): 
        self.id = data['id']
        self.name = data['name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
    
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM languages;"
        results = connectToMySQL('dojo_survey_schema').query_db(query)
        languages = []
        for language in results:
            languages.append(cls(language))
        
        return languages
    
    @classmethod
    def get_one_language(cls, data):
        query = "SELECT * FROM languages WHERE languages.id = %(id)s;"
        results = connectToMySQL('dojo_survey_schema').query_db(query, data)

        # print (results)
        language = Language(results[0])

        return language
    
    # @classmethod
    # def save(cls, data):
    #     query = "INSERT INTO dojos (name, created_at, updated_at) VALUES ( %(name)s, NOW(), NOW());"
        
    #     return connectToMySQL('dojos_and_ninjas_schema').query_db(query, data)