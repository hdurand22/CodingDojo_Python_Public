from flask import render_template, redirect, request, session
from flask_app import app
from flask_app.models import user, dojo, language

@app.route('/survey_response', methods = ['POST'])
def create_response():
    if not user.User.validate_survey(request.form):
        return redirect('/')

    user_id = user.User.save(request.form)
    dojo_id = request.form['dojo_id']
    language_id = request.form['language_id']

    return redirect(f'/result/{user_id}/{dojo_id}/{language_id}')

@app.route('/result/<int:user_id>/<int:dojo_id>/<int:language_id>')
def show_result(user_id, dojo_id, language_id):
    survey = user.User.get_survey({'id': user_id})
    survey_user = user.User(survey[0])    
    user_dojo = dojo.Dojo.get_one_dojo({'id': dojo_id})
    user_language = language.Language.get_one_language({'id': language_id})

    return render_template('result.html', survey = survey_user, dojo=user_dojo, language = user_language)
