from flask import render_template, redirect, request, session
from flask_app import app
from flask_app.models import email

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/email_validation', methods = ['POST'])
def create_email():
    if not email.Email.validate_user(request.form):
        return redirect('/')
    
    data = {
        'email': request.form['email']
    }
    
    email.Email.add_email(data)

    return redirect('/success')

@app.route('/success')
def success():
    
    all_emails = email.Email.get_all_emails()
    new_email = all_emails[(len(all_emails)-1)]['email']
    print('new email: ', new_email)
    return render_template('result.html', all_emails = all_emails, new_email = new_email)