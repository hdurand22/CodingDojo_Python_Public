from flask import render_template, redirect, request, session
from flask_app import app
from flask_app.models import ninja, dojo

@app.route('/')
def index():
    dojos = dojo.Dojo.get_all()
    return render_template('index.html', all_dojos = dojos)

@app.route('/add_dojo', methods = ['POST'])
def add_dojo():
    data = {
        'name': request.form['dojo_name']
    }
    dojo.Dojo.save(data)

    return redirect('/')

@app.route('/dojo/<int:dojo_id>')
def show_dojo(dojo_id):
    this_dojo = dojo.Dojo.get_one_dojo({'id': dojo_id })

    return render_template('dojo.html', this_dojo = this_dojo)
