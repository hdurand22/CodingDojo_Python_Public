from flask import render_template, redirect, request, session
from flask_app import app
from flask_app.models import ninja, dojo

@app.route('/create_user', methods = ['POST'])
def create_user():
    ninja.Ninja.save(request.form)
    dojo_id = request.form['dojo_id']

    return redirect(f"/dojo/{dojo_id}")

@app.route('/new_user')
def new_user():
    dojos = dojo.Dojo.get_all()
    return render_template('new_user.html', dojos = dojos)
