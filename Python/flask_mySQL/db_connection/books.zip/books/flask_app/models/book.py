from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import author

class Book:
    def __init__(self, data):
        self.id = data['id']
        self.title = data['title']
        self.num_of_pages = data['num_of_pages']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.favorited_by = []

    @classmethod
    def get_all_books(cls):
        query = "SELECT * FROM books;"
        results = connectToMySQL('books').query_db(query)
        books = []
        for book in results:
            books.append(cls(book))
        
        return books

    @classmethod
    def get_one_book(cls, data):
        query = "SELECT * FROM books LEFT JOIN favorites ON books.id = favorites.book_id LEFT JOIN authors ON favorites.author_id = authors.id WHERE books.id = %(id)s;"
        results = connectToMySQL('books').query_db(query, data)

        print(results)
        book = Book(results[0])
        if results[0]['favorites.id']:
            for row in results:
                row_data = {
                    'id': row['favorites.id'],
                    'first_name': row['first_name'],
                    'last_name': row['last_name'],
                    'created_at': row['created_at'],
                    'updated_at': row['updated_at']
                }
                book.favorited_by.append(author.Author(row_data))

        return book
    
    @classmethod
    def add_book(cls, data):
        query = "INSERT INTO books (title, num_of_pages, created_at, updated_at) VALUES ( %(title)s , %(num_of_pages)s , NOW(), NOW());"

        book_id = connectToMySQL('books').query_db(query, data)
        
        return book_id
    
    @classmethod
    def add_favorite_book(cls, data):
        query = "INSERT INTO favorites (author_id, book_id, created_at, updated_at) VALUES (%(author_id)s, %(book_id)s, NOW(), NOW());"

        return connectToMySQL('books').query_db(query, data)

