from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import book, favorite

class Author:
    def __init__(self, data): 
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.favorites = []
    
    @classmethod
    def get_all_authors(cls):
        query = "SELECT * FROM authors;"
        results = connectToMySQL('books').query_db(query)
        authors = []
        for author in results:
            authors.append(cls(author))
        
        return authors
    
    @classmethod
    def get_one_author(cls, data):
        query = "SELECT * FROM authors LEFT JOIN favorites ON authors.id = favorites.author_id LEFT JOIN books ON favorites.book_id = books.id WHERE authors.id = %(id)s;"
        results = connectToMySQL('books').query_db(query, data)

        print(results)
        author = Author(results[0])
        if results[0]['favorites.id']:
            for row in results:
                row_data = {
                    'id': row['favorites.id'],
                    'title': row['title'],
                    'num_of_pages': row['num_of_pages'],
                    'created_at': row['created_at'],
                    'updated_at': row['updated_at']
                }
                author.favorites.append(book.Book(row_data))

        return author
    
    @classmethod
    def add_author(cls, data):
        query = "INSERT INTO authors (first_name, last_name, created_at, updated_at) VALUES (%(first_name)s, %(last_name)s, NOW(), NOW());"
        
        return connectToMySQL('books').query_db(query, data)

    @classmethod
    def add_favorite(cls, data):
        query = "INSERT INTO favorites (author_id, book_id, created_at, updated_at) VALUES (%(author_id)s, %(book_id)s, NOW(), NOW());"

        return connectToMySQL('books').query_db(query, data)