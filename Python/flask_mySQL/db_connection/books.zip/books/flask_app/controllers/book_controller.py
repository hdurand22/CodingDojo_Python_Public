from flask import render_template, redirect, request, session
from flask_app import app
from flask_app.models import author, book

@app.route('/book/<int:book_id>')
def show_one_book(book_id):
    one_book = book.Book.get_one_book({'id': book_id})
    authors = author.Author.get_all_authors()
    return render_template('single_book.html', book = one_book, authors = authors)

@app.route('/books')
def show_all_books():
    books = book.Book.get_all_books()
    return render_template('books.html', books = books)

@app.route('/add_book', methods = ['POST'])
def add_book():
    book.Book.add_book(request.form)
    return redirect("/books")

@app.route('/add_favorite_book/<int:book_id>', methods = ['POST'])
def add_favorite_book(book_id):
    new_favorite = {
        'author_id': request.form['author_id'],
        'book_id': book_id
    }
    book.Book.add_favorite_book(new_favorite)

    return redirect(f'/book/{book_id}')