from flask import render_template, redirect, request, session
from flask_app import app
from flask_app.models import author, book, favorite

@app.route('/')
def index():
    authors = author.Author.get_all_authors()
    return render_template('index.html', all_authors = authors)

@app.route('/add_author', methods = ['POST'])
def add_author():
    author.Author.add_author(request.form)

    return redirect('/')

@app.route('/author/<int:author_id>')
def show_author(author_id):
    this_author = author.Author.get_one_author({'id': author_id })
    books = book.Book.get_all_books()

    return render_template('single_author.html', author = this_author, books = books)

@app.route('/add_favorite/<int:author_id>', methods = ['POST'])
def add_favorite(author_id):
    new_favorite = {
        'author_id': author_id,
        'book_id': request.form['new_favorite']
    }
    author.Author.add_favorite(new_favorite)

    return redirect(f'/author/{author_id}')
