from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash 
from flask_app.models import user

class Recipe:
    def __init__(self, data):
        self.id = data['id']
        self.user_id = data['user']
        self.name = data['name']
        self.description = data['description']
        self.instructions = data['instructions']
        self.under_30 = data['under_30']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def get_all_recipes(cls):
        query = "SELECT * FROM recipes;"
        results = connectToMySQL('recipes_schema').query_db(query)
        recipes = []
        for recipe in results:
            recipes.append(cls(recipe))
        
        return recipes

    @classmethod
    def get_one_recipe(cls, data):
        query = "SELECT * FROM recipes LEFT JOIN users ON recipes.user_id = users.id WHERE recipes.id = %(id)s;"
        results = connectToMySQL('recipes_schema').query_db(query, data)

        print(results)
        recipe = {
            'id': results[0]['id'],
            'user_id': results[0]['users.id'],
            'name': results[0]['name'],
            'description': results[0]['description'],
            'instructions': results[0]['instructions'],
            'under_30': results[0]['under_30'],
            'created_at': results[0]['created_at'],
            'updated_at': results[0]['updated_at']
        }

        return recipe
    
    @classmethod
    def add_recipe(cls, data):
        query = "INSERT INTO recipes (user_id, name, description, instructions, under_30, created_at, updated_at) VALUES ( %(user_id)s, %(name)s, %(description)s, %(instructions)s, %(under_30)s, NOW(), NOW());"

        recipe_id = connectToMySQL('recipes_schema').query_db(query, data)
        
        return recipe_id

    @classmethod
    def edit_recipe(cls, data):
        query = "UPDATE recipes SET user_id = %(user_id)s, name = %(name)s, description = %(description)s, instructions = %(instructions)s, under_30 = %(under_30)s, updated_at = NOW() WHERE recipes.id = %(id)s;"

        recipe_id = connectToMySQL('recipes_schema').query_db(query, data)
        
        return recipe_id
    
    @classmethod
    def delete_recipe(cls, data):
        query = "DELETE FROM recipes WHERE recipes.id = %(id)s;"

        return connectToMySQL('recipes_schema').query_db(query, data)
    
    @staticmethod
    def validate_recipe_input(input):
        is_valid = True # we assume this is true
        
        # Check first and last name
        if len(input['name']) < 2:
            flash("Name must be at least 2 characters.")
            is_valid = False
        if len(input['description']) < 2:
            flash("Description must be at least 2 characters.")
            is_valid = False
        if len(input['instructions']) < 2:
            flash("Instructions must be at least 2 characters.")
            is_valid = False
        
        return is_valid

