from flask import render_template, redirect, request, session
from flask_app import app
from flask_app.models import recipe, user

@app.route('/view_recipe/<int:recipe_id>')
def show_one_recipe(recipe_id):
    this_recipe = recipe.Recipe.get_one_recipe({'id': recipe_id})
    this_user = user.User.get_user_by_id({'id': session['uuid']})

    return render_template('view_recipe.html', recipe = this_recipe, user = this_user)

@app.route('/create_recipe')
def create_recipe():
    return render_template('add_recipe.html')

@app.route('/add_recipe', methods = ['POST'])
def add_recipe():
    if not recipe.Recipe.validate_recipe_input(request.form):
        return redirect('/create_recipe')

    data = {
        'user_id': session['uuid'],
        'name': request.form['name'],
        'description': request.form['description'],
        'instructions': request.form['instructions'],
        'under_30': request.form['under_30']
    }
    recipe.Recipe.add_recipe(data)
    return redirect("/dashboard")

@app.route('/edit_recipe/<int:recipe_id>')
def edit_recipe(recipe_id):
    this_recipe = recipe.Recipe.get_one_recipe({'id': recipe_id})
    this_user = user.User.get_user_by_id({'id': session['uuid']})
    return render_template('edit_recipe.html', recipe = this_recipe, user = this_user)

@app.route('/update_recipe/<int:recipe_id>', methods = ['POST'])
def update_recipe(recipe_id):
    if not recipe.Recipe.validate_recipe_input(request.form):
        return redirect(f'/edit_recipe/{recipe_id}')
    
    input = {
        'id': recipe_id,
        'user_id': session['uuid'],
        'name': request.form['name'],
        'description': request.form['description'],
        'instructions': request.form['instructions'],
        'under_30': request.form['under_30']
    }
    recipe.Recipe.edit_recipe(input)
    return redirect("/dashboard")

@app.route('/delete_recipe/<int:recipe_id>')
def delete_recipe(recipe_id):
    recipe.Recipe.delete_recipe({'id': recipe_id})
    return redirect("/dashboard")
