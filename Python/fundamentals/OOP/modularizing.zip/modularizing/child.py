import parent

print(locals())

