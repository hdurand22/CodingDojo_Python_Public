from mathdojo import MathDojo

md = MathDojo()

# print(md.add(1, 10, 10, 20))
# print(md.add(1, 10, 10, 20, 5, 5))
# print(md.add(1, 10, 10, 20, 6, 7, 8))
# print(md.subtract(1, 10, 10, 20))
# print(md.subtract(1, 10, 10, 20, 5, 5))
# print(md.subtract(1, 10, 10, 20, 6, 7, 8))

x = md.add(2).add(2,5,1).subtract(3,2).result
print(x)