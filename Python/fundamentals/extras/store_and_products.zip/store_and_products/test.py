from my_modules.product import Product
from my_modules.store import Store

store = Store('Bargain Outlet')

lawnmower = Product(1, "Lawnmower", 250, "Home & Garden")
hose = Product(2, "Hose", 20, "Home & Garden")
jacket = Product(3, "Jacket", 100, "Clothing")

store.add_product(lawnmower)
store.add_product(hose)
store.add_product(jacket)

store.inflation(0.13)
store.sell_product(2)

for product in store.products:
    product.print_info()
