from slist import SList
from node import SLNode

my_list = SList()
my_list.add_to_front('are').add_to_front("linked lists").add_to_back('fun!').print_values()

my_list.insert_at('I guess', 5)
my_list.print_values()

my_list.remove_val('fffffffffff')
my_list.print_values()