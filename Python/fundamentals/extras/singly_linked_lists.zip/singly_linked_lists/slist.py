from node import SLNode

class SList:
    def __init__(self):
        self.head = None
    
    def add_to_front(self, val):
        new_node = SLNode(val)
        current_head = self.head	# save the current head in a variable
        new_node.next = current_head
        self.head = new_node

        return self
    
    def add_to_back(self, val):
        if self.head == None:
            self.add_to_front(val)
            return self

        new_node = SLNode(val)
        runner = self.head
        while (runner.next != None):
            runner = runner.next
        runner.next = new_node
    
        return self
    
    def remove_from_front(self):
        previous_head = self.head # This will be the front node in the SList
        self.head = previous_head.next

        return previous_head.value

    def remove_from_back(self):
        runner = self.head # This will be the front node in the SList

        while (runner.next.next != None): # last node will have a next value of none
            runner = runner.next # Increment the runner to the next node until the .next value of the next node is None

        back_node_value = runner.next.value # store last element as a variable so it can be returned
        runner.next = None

        return back_node_value
    
    def remove_val(self, val):
        runner = self.head
        # If the head has the matching value, move the head to be the next node
        if runner.value == val:
            self.head = runner.next
            return self

        # Look for the value in the middle of the list
        # Once the value is found, set the runner.next node to runner.next.next node
        while (runner.next != None):
            if runner.next.value == val: 
                if runner.next.next != None:
                    runner.next = runner.next.next
                else:
                    runner.next = None
                    return self
            runner = runner.next

        return self
    
    def insert_at(self, val, n):
        # Insert as the first node
        if n == 0:
            self.add_to_front(val)
            return self
        
        # Get length of list
        length = 0
        runner = self.head
        while runner != None:
            length += 1
            runner = runner.next
        
        # After getting the length of the list, if n is larger than the list, return false because it can't happen
        if n > length:
            return False
        elif n == length:
            self.add_to_back(val)
            return self
        else:
            new_node = SLNode(val)
            runner = self.head # Reset the runner to the top of the list
            position = 0 # Count position in list
            while position < n:
                if (position+1 == n):
                    insert = runner.next # Get the node to the right of the current node and store it
                    runner.next = new_node
                    new_node.next = insert
                    return self
                else:
                    position += 1
                    runner = runner.next


    def print_values(self):
        runner = self.head
        while (runner != None):
            print(runner.value)
            runner = runner.next
        
        return self

